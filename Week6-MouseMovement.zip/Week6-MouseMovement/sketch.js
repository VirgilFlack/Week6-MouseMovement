let bgColor = 'white';
let value = 0;

function setup( ){
createCanvas(windowWidth, windowHeight);
background(bgColor);
//Red Button
let redButton;
redButton = createButton('Red');
redButton.size(100, 100);
redButton.position(20, 20);
redButton.style('background:red');
redButton.mousePressed(changeRed);
//Green Button
let greenButton;
greenButton = createButton('Green');
greenButton.size(100, 100);
greenButton.position(20, 120);
greenButton.style('background:green');
greenButton.mousePressed(changeGreen);
//Blue Button
let blueButton;
blueButton = createButton('Blue');
blueButton.size(100, 100);
blueButton.position(20, 220 );
blueButton.style('background:blue');
blueButton.mousePressed(changeBlue);
//Black Button
let blackButton;
blackButton = createButton('Black');
blackButton.size(100, 100);
blackButton.position(20, 320);
blackButton.style('backgorund:white');
blackButton.mousePressed(changeBlack);
//Clear Page
let clearButton;
clearButton = createButton('Eraser');
clearButton.size(100, 100);
clearButton.position(20, 420);
clearButton.style('backgorund:White');
clearButton.mousePressed(changeEraser);
}
function changeRed( ){
    fill('Red');
}
function changeGreen( ){
    fill('Green');
}
function changeBlue( ){
    fill('Blue');
}
function changeBlack( ){
    fill('Black');
}
function changeEraser( ){
    fill('White');
}

  function draw( ) {
        if (mouseIsPressed) {
            ellipse(mouseX, mouseY, 10, 10);
            noStroke();
        }

}










